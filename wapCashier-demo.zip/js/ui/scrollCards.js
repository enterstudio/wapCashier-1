/* scrollCards.js */
define(function(require, exports, module) {
    var Class = require('class');
    var $ = require('jquery'), 
        _ = require('underscore'),
        Backbone = require('backbone');
    var BaseModel = require('http://localhost:8000/wapCashier/js/model/base');
    var ScrollCards = BaseModel.extend({
        options:{
        },
        initialize:function(canvas,options){
            var that = this;
            ScrollCards.superclass.initialize.apply(that,[options]);
        }
    });
	module.exports = ScrollCards;
});